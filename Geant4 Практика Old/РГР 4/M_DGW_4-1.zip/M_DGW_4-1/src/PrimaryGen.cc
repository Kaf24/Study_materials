#include <Randomize.hh>
#include <G4Electron.hh>
#include "PrimaryGen.hh"
#include "fstream"
#include "vector"
PrimaryGen::PrimaryGen() {
    gun = new G4ParticleGun(1);

}

PrimaryGen::~PrimaryGen()
{ }

void PrimaryGen::GeneratePrimaries(G4Event* anEvent) {

    gun->GeneratePrimaryVertex(anEvent);
}
