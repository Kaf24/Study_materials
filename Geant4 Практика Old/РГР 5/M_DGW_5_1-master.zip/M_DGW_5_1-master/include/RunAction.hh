//
// Created by idalov on 12.05.18.
//

#ifndef TEMPLATE_RUNACTION_HH
#define TEMPLATE_RUNACTION_HH

#include <G4UserRunAction.hh>

class RunAction: public G4UserRunAction{


};
#endif //TEMPLATE_RUNACTION_HH
