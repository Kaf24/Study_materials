#include <iostream>
#include <Loader.hh>

int main(int argc, char** argv) {
    Loader loader(argc,argv);
    return 0;
}