
#include <G4PhysicalConstants.hh>
#include <G4VisAttributes.hh>
#include <G4Sphere.hh>
#include <G4Tubs.hh>
#include "DetGeometry.hh"

DetGeometry::DetGeometry() {
    world_sizeXYZ   = 50 * m;
    nist            = G4NistManager::Instance();
    material       = nist->FindOrBuildMaterial("G4_AIR");
    solidWorld      = new G4Box("solWorld", 0.5*world_sizeXYZ, 0.5*world_sizeXYZ, 0.5*world_sizeXYZ);
    logicWorld      = new G4LogicalVolume(solidWorld, material, "logWorld");
    physWorld       = new G4PVPlacement(0, G4ThreeVector(), logicWorld, "phyWorld", 0, false, 0);
   }

DetGeometry::~DetGeometry() {}

G4VPhysicalVolume* DetGeometry::Construct(){
    G4Box * gamma_orb = new G4Box("g_o", 100*mm, 100*mm, 100*mm);
    G4LogicalVolume* log_gamma_orb = new G4LogicalVolume(gamma_orb, material, "log_g_o");
    log_gamma_orb->SetVisAttributes(G4Color(0.0, 1.00, 0.0));
    new G4PVPlacement(0, G4ThreeVector(0,0,-200),log_gamma_orb,"pl_g_b",logicWorld,false,0);
    auto beta_tube = new G4Tubs("b_t",0,150,40,0,360*deg);
    G4LogicalVolume* log_beta_tube = new G4LogicalVolume(beta_tube, material, "log_b_s");
    log_beta_tube->SetVisAttributes(G4Color::Cyan());
    new G4PVPlacement(0, G4ThreeVector(0,-300,200),log_beta_tube,"pl_b_s",logicWorld,false,0);
    G4cout<<"Geometry of detector is build successfully\t\t\t\t\t\tOK!!!"<<G4endl;
    return physWorld;
}


