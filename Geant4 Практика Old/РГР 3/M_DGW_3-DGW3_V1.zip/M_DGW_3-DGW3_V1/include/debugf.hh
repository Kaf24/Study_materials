
#ifndef CPROJECT_DEBUGFUNCTION_HH
#define CPROJECT_DEBUGFUNCTION_HH
#include <iostream>
void sysstop();

#endif //CPROJECT_DEBUGFUNCTION_HH
