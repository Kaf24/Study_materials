

#ifndef CPROJECT_RUNGEN_HH
#define CPROJECT_RUNGEN_HH

#include <G4UserRunAction.hh>
#include "Run.hh"

class G4Run;

class RunGen : public G4UserRunAction {
public:
    RunGen();
    ~RunGen();
    virtual G4Run* GenerateRun();
private:

};

#endif //CPROJECT_RUNGEN_HH
