
#include "PrimaryGen.hh"

PrimaryGen::PrimaryGen()
{

    G4cout<<"Primary particles generator is created successfully\t\tOK!!!"<<G4endl;
}

PrimaryGen::~PrimaryGen()
{ }

void PrimaryGen::GeneratePrimaries(G4Event* anEvent)
{


}