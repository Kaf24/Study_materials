
#include "debugf.hh"

void sysstop(){
    printf("Please press any button...");
    getchar();
}