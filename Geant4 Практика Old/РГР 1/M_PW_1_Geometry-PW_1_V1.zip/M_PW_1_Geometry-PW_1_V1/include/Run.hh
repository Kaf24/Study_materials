
#include <G4Run.hh>

#ifndef CPROJECT_RUN_HH
#define CPROJECT_RUN_HH

class Run : public G4Run
{
public:
    Run();
    ~Run();
private:

};


#endif //CPROJECT_RUN_HH
