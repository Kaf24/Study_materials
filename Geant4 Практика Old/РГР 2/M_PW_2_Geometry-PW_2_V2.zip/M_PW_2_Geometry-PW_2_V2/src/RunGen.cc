
#include "RunGen.hh"
RunGen::RunGen()
{
    G4cout<<"Run generator is created successfully\t\t\t\t\tOK!!!"<<G4endl;
}

RunGen::~RunGen()
{ }

G4Run* RunGen::GenerateRun()
{
    return new Run;
}