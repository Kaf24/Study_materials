
# Вариант 1
Реализовать составную геометрию представленную на рисунке

![Task](https://github.com/dep24/M_PW_2_Geometry/blob/PW_2_V1/Screenshot_20170317_164838.png)
